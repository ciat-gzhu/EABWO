"""
EABWO vs 经典群智能算法对比实验
算法: GA, PSO, ABC, BA, BWO, EABWO
数据集: 通过 --dataset 指定预处理 CSV 文件
"""

import argparse
from pathlib import Path
import numpy as np
import cupy as cp
import pandas as pd
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import accuracy_score, f1_score
import xgboost as xgb
import time
import warnings

warnings.filterwarnings('ignore')

# ─────────────────────────────────────────────────────────────
# mealpy 导入
# ─────────────────────────────────────────────────────────────
try:
    from mealpy import FloatVar
    from mealpy.evolutionary_based import GA
    from mealpy.swarm_based import PSO, ABC, BA
    MEALPY_AVAILABLE = True
except ImportError:
    MEALPY_AVAILABLE = False
    print("错误: mealpy 未安装，请运行 pip install mealpy")

# ─────────────────────────────────────────────────────────────
# BWO / EABWO 导入（本地实现）
# ─────────────────────────────────────────────────────────────
from BWO import BWO
from EABWO import EABWO

# ═════════════════════════════════════════════════════════════
# 实验配置
# ═════════════════════════════════════════════════════════════
SCRIPT_DIR      = Path(__file__).resolve().parent
LABEL_COLUMN    = 'Label'
USE_SAMPLING    = True    # True=分层抽样, False=使用全部数据
SAMPLE_SIZE     = 20000   # 沿用原有抽样设置
N_POPULATION    = 30
N_ITERATIONS    = 50
N_RUNS          = 5
BASE_SEED       = 42      # 五轮分别使用42、43、44、45、46
CV_FOLDS        = 3
ALPHA           = 0.01
TEST_SIZE       = 0.3
XGB_VERSION     = tuple(int(v) for v in xgb.__version__.split('.')[:2])


def gpu_classifier_params(n_classes, seed):
    """适应度与最终测试使用相同的 GPU XGBoost 参数。"""
    params = dict(
        max_depth=6, n_estimators=100, random_state=seed,
        verbosity=0, n_jobs=-1
    )
    if XGB_VERSION >= (2, 0):
        params.update(tree_method='hist', device='cuda')
    else:
        params['tree_method'] = 'gpu_hist'
    if n_classes == 2:
        params['objective'] = 'binary:logistic'
    else:
        params.update(objective='multi:softmax', num_class=n_classes)
    return params


# ═════════════════════════════════════════════════════════════
# 数据加载与分层抽样
# ═════════════════════════════════════════════════════════════
def load_and_sample(filepath, label_col, use_sampling, sample_size, seed):
    print(f"\n加载数据: {filepath}")
    df = pd.read_csv(filepath)
    print(f"  原始数据形状: {df.shape}")

    if use_sampling:
        # 分层抽样：保持类别比例
        df_used, _ = train_test_split(
            df,
            train_size=sample_size,
            stratify=df[label_col],
            random_state=seed
        )
        print(f"  抽样后形状:   {df_used.shape}  (已启用分层抽样)")
    else:
        df_used = df
        print(f"  使用全部数据: {df_used.shape}  (未采样，注意运行时间)")

    print(f"  类别分布:\n{df_used[label_col].value_counts().to_string()}")

    X = df_used.drop(columns=[label_col]).values.astype(np.float64)
    y = df_used[label_col].values

    le = LabelEncoder()
    y = le.fit_transform(y)

    return X, y, le.classes_


# ═════════════════════════════════════════════════════════════
# 适应度评估器（固定3折交叉验证，GPU训练）
# ═════════════════════════════════════════════════════════════
class FitnessEvaluator:
    """最小化交叉验证错误率与特征数惩罚，预先保存每轮的折划分。"""

    def __init__(self, X_train, y_train, n_features, alpha, cv_folds, seed, n_classes):
        self.n_features = n_features
        self.alpha = alpha
        self.n_classes = n_classes
        self.seed = seed
        self.X_train = cp.asarray(X_train, dtype=cp.float64)
        self.y_train = cp.asarray(y_train)
        skf = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=seed)
        self.cv_splits = [
            (cp.asarray(train_idx), cp.asarray(val_idx))
            for train_idx, val_idx in skf.split(
                np.zeros(len(y_train), dtype=np.uint8), y_train
            )
        ]
        self.clf_params = gpu_classifier_params(n_classes, seed)

    def _binary_encode(self, position):
        """sigmoid 阈值 0.5 二值化，保证至少选一个特征"""
        # CuPy 优化器传入 GPU 位置，Mealpy/BWO 传入 NumPy 位置。
        if isinstance(position, cp.ndarray):
            position = cp.asnumpy(position)
        pos_clipped = np.clip(position, -500, 500)
        sigmoid = 1.0 / (1.0 + np.exp(-pos_clipped))
        binary = (sigmoid > 0.5).astype(int)
        if np.sum(binary) == 0:
            binary[np.random.randint(0, len(binary))] = 1
        return binary

    def evaluate(self, position):
        """供 EABWO / mealpy 调用的统一适应度接口"""
        binary = self._binary_encode(position)
        selected = np.where(binary == 1)[0]

        if len(selected) == 0:
            return 1.0 + self.alpha

        X_selected = self.X_train[:, cp.asarray(selected)]

        try:
            scores = []
            for train_idx, val_idx in self.cv_splits:
                clf = xgb.XGBClassifier(**self.clf_params)
                clf.fit(X_selected[train_idx], self.y_train[train_idx])
                y_pred = cp.asarray(clf.predict(X_selected[val_idx]))
                scores.append(float(cp.mean(y_pred == self.y_train[val_idx])))
            error_rate = 1.0 - float(np.mean(scores))
            feature_penalty = self.alpha * (len(selected) / self.n_features)
            return error_rate + feature_penalty
        except Exception:
            return 1.0 + self.alpha

    def decode_position(self, position):
        """将连续位置解码为选择的特征索引列表"""
        binary = self._binary_encode(position)
        return np.where(binary == 1)[0].tolist()


# ═════════════════════════════════════════════════════════════
# 最终测试集评估（holdout，特征选择完成后调用一次）
# ═════════════════════════════════════════════════════════════
def evaluate_on_test(X_train, y_train, X_test, y_test,
                     selected_indices, n_classes, n_features, seed):
    if len(selected_indices) == 0:
        return 0.0, 0.0, 1.0, 0

    clf = xgb.XGBClassifier(**gpu_classifier_params(n_classes, seed))
    selected = cp.asarray(selected_indices)
    clf.fit(X_train[:, selected], cp.asarray(y_train))
    y_pred = cp.asnumpy(cp.asarray(clf.predict(X_test[:, selected])))

    accuracy = accuracy_score(y_test, y_pred)
    avg_method = 'binary' if n_classes == 2 else 'weighted'
    f1 = f1_score(y_test, y_pred, average=avg_method, zero_division=0)
    feature_selection_rate = len(selected_indices) / n_features

    return accuracy, f1, feature_selection_rate, len(selected_indices)


# ═════════════════════════════════════════════════════════════
# 运行单个 mealpy 算法
# ═════════════════════════════════════════════════════════════
def run_mealpy(algo_class, algo_name, evaluator, n_features, run_seed):
    np.random.seed(run_seed)
    cp.random.seed(run_seed)

    problem_dict = {
        "obj_func": evaluator.evaluate,
        "bounds":   FloatVar(lb=[-6.0] * n_features, ub=[6.0] * n_features),
        "minmax":   "min",
        "log_to":   None,
    }

    model = algo_class(epoch=N_ITERATIONS, pop_size=N_POPULATION)

    start = time.time()
    try:
        g_best = model.solve(problem_dict, seed=run_seed)
    except TypeError:
        # 部分旧版 mealpy 的 solve() 不接受 seed 参数
        g_best = model.solve(problem_dict)
    elapsed = time.time() - start

    best_position = np.array(g_best.solution)
    best_fitness  = float(g_best.target.fitness)

    # 收敛曲线（每轮最优适应度，长度 = N_ITERATIONS）
    convergence_curve = [float(v) for v in model.history.list_global_best_fit]

    # 最终种群各个体适应度
    try:
        pop = model.population
    except AttributeError:
        pop = model.pop
    final_pop_fitness = [float(agent.target.fitness) for agent in pop]

    return best_position, best_fitness, convergence_curve, final_pop_fitness, elapsed


# ═════════════════════════════════════════════════════════════
# 运行 BWO（本地复现，接口与 run_eabwo 完全一致）
# ═════════════════════════════════════════════════════════════
def run_bwo(evaluator, n_features, run_seed):
    np.random.seed(run_seed)
    cp.random.seed(run_seed)

    optimizer = BWO(
        N=N_POPULATION,
        T=N_ITERATIONS,
        lb=-6.0,
        ub=6.0,
        dim=n_features,
        fobj=evaluator.evaluate
    )

    start = time.time()
    best_fitness, best_position, convergence_curve = optimizer.optimize(verbose=False)
    elapsed = time.time() - start

    best_position     = np.array(best_position)
    best_fitness      = float(best_fitness)
    convergence_curve = [float(v) for v in convergence_curve]

    # optimizer.fit 保存最终种群各个体适应度
    final_pop_fitness = [float(v) for v in optimizer.fit]

    return best_position, best_fitness, convergence_curve, final_pop_fitness, elapsed


# ═════════════════════════════════════════════════════════════
# 运行 EABWO
# ═════════════════════════════════════════════════════════════
def run_eabwo(evaluator, n_features, run_seed):
    np.random.seed(run_seed)
    cp.random.seed(run_seed)

    optimizer = EABWO(
        N=N_POPULATION,
        T=N_ITERATIONS,
        lb=-6.0,
        ub=6.0,
        dim=n_features,
        fobj=evaluator.evaluate
    )

    start = time.time()
    best_fitness, best_position, convergence_curve = optimizer.optimize(verbose=False)
    elapsed = time.time() - start

    best_position     = np.array(best_position)
    best_fitness      = float(best_fitness)
    convergence_curve = [float(v) for v in convergence_curve]

    # optimizer.fit 保存最终种群各个体适应度
    final_pop_fitness = cp.asnumpy(optimizer.fit).tolist()

    return best_position, best_fitness, convergence_curve, final_pop_fitness, elapsed


# ═════════════════════════════════════════════════════════════
# 主流程
# ═════════════════════════════════════════════════════════════
def main():
    parser = argparse.ArgumentParser(description="EABWO 特征选择对比实验 (GPU，3折，5轮)")
    parser.add_argument("--dataset", required=True, help="相对于脚本目录的 CSV 路径，也支持绝对路径")
    parser.add_argument("--label", default=LABEL_COLUMN, help="标签列名 (默认 Label)")
    parser.add_argument("--save_dir", default=None, help="结果目录 (默认 results/数据集名/comparison)")
    args = parser.parse_args()
    data_path = SCRIPT_DIR / args.dataset
    save_dir = (SCRIPT_DIR / args.save_dir if args.save_dir is not None
                else SCRIPT_DIR / "results" / data_path.stem / "comparison")
    save_dir.mkdir(parents=True, exist_ok=True)
    out_main = save_dir / "results_main.csv"
    out_convergence = save_dir / "results_convergence.csv"
    out_population = save_dir / "results_final_population.csv"

    if not MEALPY_AVAILABLE:
        print("错误: mealpy 未安装，实验终止")
        return

    # ── 1. 加载数据 ──────────────────────────────────────────
    X_all, y_all, class_names = load_and_sample(
        data_path, args.label, USE_SAMPLING, SAMPLE_SIZE, BASE_SEED
    )
    n_features = X_all.shape[1]
    n_classes  = len(np.unique(y_all))
    print(f"\n总特征数: {n_features}  |  类别数: {n_classes}  |  类别: {class_names}")

    # ── 2. 算法列表 ───────────────────────────────────────────
    # mealpy 算法（通过 mealpy 框架运行）
    mealpy_algorithms = [
        ('GA',  GA.BaseGA),
        ('PSO', PSO.OriginalPSO),
        ('ABC', ABC.OriginalABC),
        ('BA',  BA.OriginalBA),
    ]
    # 本地自实现算法（BWO / EABWO，接口统一）
    local_algorithms = [
        ('BWO',   run_bwo),
        ('EABWO', run_eabwo),
    ]

    all_algo_names = [name for name, _ in mealpy_algorithms] + \
                     [name for name, _ in local_algorithms]

    # ── 3. 结果容器 ───────────────────────────────────────────
    rows_main        = []   # 每算法每轮的汇总指标
    rows_convergence = []   # 每算法每轮每次迭代的最优适应度
    rows_population  = []   # 每算法每轮最终种群各个体适应度

    # ── 4. 实验主循环 ─────────────────────────────────────────
    for run_idx in range(N_RUNS):
        run_seed = BASE_SEED + run_idx
        print(f"\n{'═'*65}")
        print(f"  第 {run_idx + 1} / {N_RUNS} 轮   seed = {run_seed}")
        print(f"{'═'*65}")

        # 本轮数据划分（训练集 + 测试集）
        X_train, X_test, y_train, y_test = train_test_split(
            X_all, y_all,
            test_size=TEST_SIZE,
            random_state=run_seed,
            stratify=y_all
        )

        # 标准化（fit 在训练集，transform 测试集）
        scaler  = StandardScaler()
        X_train = scaler.fit_transform(X_train)
        X_test  = scaler.transform(X_test)
        # 每轮只上传一次；所有算法共享 GPU 数据及相同的交叉验证划分。
        X_train = cp.asarray(X_train, dtype=cp.float64)
        X_test = cp.asarray(X_test, dtype=cp.float64)

        # 构建适应度评估器，预生成本轮固定的3折划分
        evaluator = FitnessEvaluator(
            X_train, y_train, n_features, ALPHA, CV_FOLDS, run_seed, n_classes
        )

        # ── mealpy 算法 ──────────────────────────────────────
        for algo_name, algo_class in mealpy_algorithms:
            print(f"\n  ▶ [{algo_name}]", end='  ', flush=True)
            try:
                best_pos, best_fit, conv_curve, final_pop, elapsed = run_mealpy(
                    algo_class, algo_name, evaluator, n_features, run_seed
                )

                selected = evaluator.decode_position(best_pos)
                acc, f1, feat_rate, n_sel = evaluate_on_test(
                    X_train, y_train, X_test, y_test,
                    selected, n_classes, n_features, run_seed
                )

                print(f"acc={acc:.8f}  feat_rate={feat_rate:.8f}  "
                      f"fitness={best_fit:.8f}  time={elapsed:.1f}s")

                rows_main.append({
                    'algorithm':            algo_name,
                    'run':                  run_idx + 1,
                    'seed':                 run_seed,
                    'accuracy':             round(acc, 8),
                    'f1_score':             round(f1, 8),
                    'feature_selection_rate': round(feat_rate, 8),
                    'n_selected_features':  n_sel,
                    'n_total_features':     n_features,
                    'best_fitness':         round(best_fit, 8),
                    'selected_features':    ';'.join(map(str, selected)),
                    'computation_time':     round(elapsed, 8),
                })

                for it_idx, fit_val in enumerate(conv_curve):
                    rows_convergence.append({
                        'algorithm': algo_name,
                        'run':       run_idx + 1,
                        'iteration': it_idx + 1,
                        'best_fitness': round(fit_val, 8),
                    })

                for ind_idx, ind_fit in enumerate(final_pop):
                    rows_population.append({
                        'algorithm':  algo_name,
                        'run':        run_idx + 1,
                        'individual': ind_idx + 1,
                        'fitness':    round(ind_fit, 8),
                    })

            except Exception as e:
                print(f"\n    [错误] {algo_name} 第{run_idx+1}轮失败: {e}")

        # ── 本地算法（BWO / EABWO）────────────────────────────
        for algo_name, run_fn in local_algorithms:
            print(f"\n  ▶ [{algo_name}]", end='  ', flush=True)
            try:
                best_pos, best_fit, conv_curve, final_pop, elapsed = run_fn(
                    evaluator, n_features, run_seed
                )

                selected = evaluator.decode_position(best_pos)
                acc, f1, feat_rate, n_sel = evaluate_on_test(
                    X_train, y_train, X_test, y_test,
                    selected, n_classes, n_features, run_seed
                )

                print(f"acc={acc:.8f}  feat_rate={feat_rate:.8f}  "
                      f"fitness={best_fit:.8f}  time={elapsed:.1f}s")

                rows_main.append({
                    'algorithm':              algo_name,
                    'run':                    run_idx + 1,
                    'seed':                   run_seed,
                    'accuracy':               round(acc, 8),
                    'f1_score':               round(f1, 8),
                    'feature_selection_rate': round(feat_rate, 8),
                    'n_selected_features':    n_sel,
                    'n_total_features':       n_features,
                    'best_fitness':           round(best_fit, 8),
                    'selected_features':      ';'.join(map(str, selected)),
                    'computation_time':       round(elapsed, 8),
                })

                for it_idx, fit_val in enumerate(conv_curve):
                    rows_convergence.append({
                        'algorithm':   algo_name,
                        'run':         run_idx + 1,
                        'iteration':   it_idx + 1,
                        'best_fitness': round(fit_val, 8),
                    })

                for ind_idx, ind_fit in enumerate(final_pop):
                    rows_population.append({
                        'algorithm':  algo_name,
                        'run':        run_idx + 1,
                        'individual': ind_idx + 1,
                        'fitness':    round(ind_fit, 8),
                    })

            except Exception as e:
                print(f"\n    [错误] {algo_name} 第{run_idx+1}轮失败: {e}")

    # ── 5. 保存 CSV ───────────────────────────────────────────
    print(f"\n{'═'*65}")
    print("保存结果至 CSV ...")

    df_main        = pd.DataFrame(rows_main)
    df_convergence = pd.DataFrame(rows_convergence)
    df_population  = pd.DataFrame(rows_population)

    df_main.to_csv(out_main,        index=False, encoding='utf-8-sig')
    df_convergence.to_csv(out_convergence, index=False, encoding='utf-8-sig')
    df_population.to_csv(out_population,  index=False, encoding='utf-8-sig')

    print(f"  ✓ 主结果       → {out_main}")
    print(f"  ✓ 收敛曲线     → {out_convergence}")
    print(f"  ✓ 最终种群适应度 → {out_population}")

    # ── 6. 控制台汇总（5轮均值±标准差）────────────────────────
    if not df_main.empty:
        print(f"\n{'═'*65}")
        print(f"结果汇总（{N_RUNS}轮均值 ± 标准差）")
        print(f"{'═'*65}")

        summary = (
            df_main.groupby('algorithm')
            .agg(
                acc_mean  =('accuracy',              'mean'),
                acc_std   =('accuracy',              'std'),
                f1_mean   =('f1_score',              'mean'),
                f1_std    =('f1_score',              'std'),
                feat_mean =('feature_selection_rate','mean'),
                feat_std  =('feature_selection_rate','std'),
                fit_mean  =('best_fitness',          'mean'),
                fit_std   =('best_fitness',          'std'),
                time_mean =('computation_time',      'mean'),
                time_std  =('computation_time',      'std'),
            )
            .round(4)
            .reindex(all_algo_names, fill_value=float('nan'))
        )

        header = f"{'算法':<8} {'准确率':>14} {'F1分数':>14} {'特征选择率':>14} {'适应度':>14} {'耗时(s)':>12}"
        print(header)
        print('-' * 80)
        for algo in all_algo_names:
            if algo not in summary.index:
                continue
            row = summary.loc[algo]
            print(
                f"{algo:<8} "
                f"{row['acc_mean']:.8f}±{row['acc_std']:.8f}  "
                f"{row['f1_mean']:.8f}±{row['f1_std']:.8f}  "
                f"{row['feat_mean']:.8f}±{row['feat_std']:.8f}  "
                f"{row['fit_mean']:.8f}±{row['fit_std']:.8f}  "
                f"{row['time_mean']:.1f}±{row['time_std']:.1f}"
            )

    print(f"\n实验完成！")


if __name__ == '__main__':
    main()
