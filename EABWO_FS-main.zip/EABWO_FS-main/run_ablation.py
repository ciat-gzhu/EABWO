import argparse
import os
import sys
from pathlib import Path
import pandas as pd
import numpy as np
import cupy as cp
import warnings
warnings.filterwarnings('ignore')

from EABWO_Featureselection import FeatureSelectionEABWO

EXPERIMENTS = {
        "Base_BWO + XGBoost": {"use_xgboost": True, "use_s1": False, "use_s2": False, "use_s3": False},
        "S1 + XGBoost": {"use_xgboost": True, "use_s1": True, "use_s2": False, "use_s3": False},
        "S2 + XGBoost": {"use_xgboost": True, "use_s1": False, "use_s2": True, "use_s3": False},
        "S3 + XGBoost": {"use_xgboost": True, "use_s1": False, "use_s2": False, "use_s3": True},
        "S1+S2 + XGBoost": {"use_xgboost": True, "use_s1": True, "use_s2": True, "use_s3": False},
        "S1+S3 + XGBoost": {"use_xgboost": True, "use_s1": True, "use_s2": False, "use_s3": True},
        "S2+S3 + XGBoost": {"use_xgboost": True, "use_s1": False, "use_s2": True, "use_s3": True},
        "EABWO + XGBoost": {"use_xgboost": True, "use_s1": True, "use_s2": True, "use_s3": True}
    }


def merge_shards(save_dir, dataset_name, runs):
    """合并各分片 CSV 并重算统计量，输出最终 summary/detail"""
    import glob
    pattern = os.path.join(save_dir, f"ablation_{dataset_name}_shard*_detail.csv")
    files = sorted(glob.glob(pattern))
    if not files:
        print(f"未找到分片结果: {pattern}")
        return

    df = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
    df = df.drop_duplicates(subset=["Configuration", "Run"], keep="last")
    df["Configuration"] = pd.Categorical(df["Configuration"], categories=list(EXPERIMENTS.keys()), ordered=True)
    df = df.sort_values(["Configuration", "Run"])

    rows = []
    for name, strat in EXPERIMENTS.items():
        g = df[df["Configuration"] == name]
        if len(g) != runs:
            print(f"警告: {name} 只有 {len(g)}/{runs} 个 run")
        if g.empty:
            continue
        fit, acc = g["Fitness"].to_numpy(), g["Accuracy"].to_numpy()
        f1, nf = g["F1-Score"].to_numpy(), g["Num_Features"].to_numpy()
        rows.append({
            "Configuration": name,
            "S1": "\u2713" if strat["use_s1"] else "\u2014",
            "S2": "\u2713" if strat["use_s2"] else "\u2014",
            "S3": "\u2713" if strat["use_s3"] else "\u2014",
            "Best Fitness": fit.min(), "Worst Fitness": fit.max(),
            "Mean Fitness": fit.mean(), "Std Fitness": fit.std(),
            "Mean Accuracy": acc.mean(), "Std Accuracy": acc.std(),
            "Mean F1-Score": f1.mean(), "Std F1-Score": f1.std(),
            "Mean Num Features": nf.mean(), "Std Num Features": nf.std(),
            "Runs": len(g),
        })

    df_results = pd.DataFrame(rows)
    df_detail = df.reset_index(drop=True)
    df_detail["Configuration"] = df_detail["Configuration"].astype(str)

    pd.options.display.float_format = '{:.4f}'.format
    print("=" * 120)
    print(df_results.to_string(index=False))
    print("=" * 120)
    df_results.to_csv(os.path.join(save_dir, f"ablation_{dataset_name}_summary.csv"), index=False)
    df_detail.to_csv(os.path.join(save_dir, f"ablation_{dataset_name}_detail.csv"), index=False)
    print(f"已合并 {len(files)} 个分片 -> ablation_{dataset_name}_summary.csv / _detail.csv")


if __name__ == "__main__":
    # 1. 命令行参数解析
    parser = argparse.ArgumentParser(description="EABWO 特征选择消融实验 (GPU)")
    parser.add_argument("--dataset", type=str, required=True, help="相对于脚本目录的 CSV 路径，也支持绝对路径")
    parser.add_argument("--label", type=str, default=None, help="标签列名 (默认使用最后一列)")
    parser.add_argument("--runs", type=int, default=5, help="每种配置独立运行次数 (默认5)")
    parser.add_argument("--save_dir", type=str, default=None, help="结果目录 (默认 results/数据集名/ablation)")
    parser.add_argument("--max_samples", type=int, default=50000, help="下采样最大样本数 (0表示不下采样, 默认50000)")
    parser.add_argument("--shard", type=int, default=0, help="本进程负责的分片编号 (0 起)")
    parser.add_argument("--nshards", type=int, default=1, help="分片总数，多卡并行时等于 GPU 数")
    parser.add_argument("--merge", action="store_true", help="只合并各分片结果，不跑实验")
    args = parser.parse_args()

    script_dir = Path(__file__).resolve().parent
    data_path = script_dir / args.dataset
    dataset_name = data_path.stem

    # 2. 实验参数
    runs = args.runs
    base_params = {
        "n_population": 30,
        "n_iterations": 50,
        "alpha": 0.01,
        "test_size": 0.3,
        "random_state": 42,
        "cv_folds": 3
    }
    
    # 3. 消融策略组合
    experiments = EXPERIMENTS

    # 4. 准备保存目录
    save_dir = (script_dir / args.save_dir if args.save_dir is not None
                else script_dir / "results" / dataset_name / "ablation")
    os.makedirs(save_dir, exist_ok=True)

    tag = f"_shard{args.shard}" if args.nshards > 1 else ""
    summary_path = os.path.join(save_dir, f"ablation_{dataset_name}{tag}_summary.csv")
    detail_path = os.path.join(save_dir, f"ablation_{dataset_name}{tag}_detail.csv")

    if args.merge:
        merge_shards(save_dir, dataset_name, runs)
        sys.exit(0)

    # 合并分片不需要加载原始数据。
    df = pd.read_csv(data_path)
    label_column = args.label if args.label else df.columns[-1]
    max_samples = args.max_samples if args.max_samples and args.max_samples > 0 else None

    results_data = []
    all_runs_detail = []
    done_keys = set()
    if os.path.exists(detail_path):
        _prev = pd.read_csv(detail_path)
        all_runs_detail = _prev.to_dict('records')
        done_keys = {(d["Configuration"], int(d["Run"])) for d in all_runs_detail}
        print(f"检测到已有结果 {len(done_keys)} 条，这些 run 将跳过")
    
    print("=" * 90)
    print(f"EABWO 特征选择消融实验 (GPU: CuPy)")
    print("=" * 90)
    print(f"数据集: {dataset_name} | 特征数: {df.shape[1]-1} | 样本数: {df.shape[0]} | 标签列: {label_column}")
    print(f"种群大小: {base_params['n_population']} | 迭代次数: {base_params['n_iterations']} | "
          f"α: {base_params['alpha']} | CV折数: {base_params['cv_folds']}")
    print("=" * 90)
    
    # 5. 执行实验循环
    for config_idx, (config_name, strategy_params) in enumerate(experiments.items(), 1):

        print(f"\n{'─'*90}")
        print(f"[{config_idx}/8] 正在评估配置: {config_name}")
        print(f"{'─'*90}")
        
        _done = [d for d in all_runs_detail if d["Configuration"] == config_name]
        run_fitness = [d["Fitness"] for d in _done]
        run_acc = [d["Accuracy"] for d in _done]
        run_f1 = [d["F1-Score"] for d in _done]
        run_precision = [d["Precision"] for d in _done]
        run_recall = [d["Recall"] for d in _done]
        run_n_features = [d["Num_Features"] for d in _done]
        
        for r in range(runs):
            if r % args.nshards != args.shard:
                continue
            if (config_name, r + 1) in done_keys:
                print(f"  Run {r+1:2d}/{runs} 已完成，跳过")
                continue
            run_seed = 42 + r  
            
            np.random.seed(run_seed)
            cp.random.seed(run_seed)
            
            current_params = base_params.copy()
            current_params.update(strategy_params)
            current_params['random_state'] = run_seed
            
            fs = FeatureSelectionEABWO(**current_params)
            fs.load_data(df, label_column=label_column, normalize=False, max_samples=max_samples)
            
            fs.fit(verbose=False)
            metrics = fs.evaluate(verbose=False)
            
            run_fitness.append(fs.best_fitness)
            run_acc.append(metrics['accuracy'])
            run_f1.append(metrics['f1_score'])
            run_precision.append(metrics['precision'])
            run_recall.append(metrics['recall'])
            run_n_features.append(metrics['n_selected_features'])

            all_runs_detail.append({
                "Configuration": config_name,
                "Run": r + 1,
                "Seed": run_seed,
                "Fitness": fs.best_fitness,
                "Accuracy": metrics['accuracy'],
                "Precision": metrics['precision'],
                "Recall": metrics['recall'],
                "F1-Score": metrics['f1_score'],
                "Num_Features": metrics['n_selected_features']
            })

            pd.DataFrame(all_runs_detail).to_csv(detail_path, index=False)

            print(f"  Run {r+1:2d}/{runs} (Seed:{run_seed}) | "
                  f"Fitness: {fs.best_fitness:.4f} | "
                  f"Acc: {metrics['accuracy']:.4f} | "
                  f"F1: {metrics['f1_score']:.4f} | "
                  f"Features: {metrics['n_selected_features']}")

        if not run_fitness:
            print(f"  当前分片没有 {config_name} 的运行结果，跳过统计")
            continue

        # 6. 计算该组合的统计指标
        run_fitness = np.array(run_fitness)
        run_acc = np.array(run_acc)
        run_f1 = np.array(run_f1)
        run_n_features = np.array(run_n_features)

        config_summary = {
            "Configuration": config_name,
            "S1": "✓" if strategy_params["use_s1"] else "—",
            "S2": "✓" if strategy_params["use_s2"] else "—",
            "S3": "✓" if strategy_params["use_s3"] else "—",
            "Best Fitness": np.min(run_fitness),
            "Worst Fitness": np.max(run_fitness),
            "Mean Fitness": np.mean(run_fitness),
            "Std Fitness": np.std(run_fitness),
            "Mean Accuracy": np.mean(run_acc),
            "Std Accuracy": np.std(run_acc),
            "Mean F1-Score": np.mean(run_f1),
            "Std F1-Score": np.std(run_f1),
            "Mean Num Features": np.mean(run_n_features),
            "Std Num Features": np.std(run_n_features)
        }
        results_data.append(config_summary)
        pd.DataFrame(results_data).to_csv(summary_path, index=False)

        print(f"\n  >>> {config_name} 统计汇总:")
        print(f"      Fitness: {np.mean(run_fitness):.4f} ± {np.std(run_fitness):.4f} "
              f"(Best: {np.min(run_fitness):.4f}, Worst: {np.max(run_fitness):.4f})")
        print(f"      Accuracy: {np.mean(run_acc):.4f} ± {np.std(run_acc):.4f}")
        print(f"      F1-Score: {np.mean(run_f1):.4f} ± {np.std(run_f1):.4f}")
        print(f"      Features: {np.mean(run_n_features):.1f} ± {np.std(run_n_features):.1f}")
        
    # 7. 生成最终数据表格
    df_results = pd.DataFrame(results_data)
    df_detail = pd.DataFrame(all_runs_detail, columns=[
        "Configuration", "Run", "Seed", "Fitness", "Accuracy",
        "Precision", "Recall", "F1-Score", "Num_Features"
    ])

    pd.options.display.float_format = '{:.4f}'.format
    
    print("\n\n" + "=" * 120)
    print(f"特征选择消融实验最终评估结果表 ({len(experiments)}种配置 × {runs}次运行)")
    print("=" * 120)
    print(df_results.to_string(index=False))
    print("=" * 120)

    # 8. 保存最终结果
    df_results.to_csv(summary_path, index=False)
    df_detail.to_csv(detail_path, index=False)

    print(f"\n汇总结果已保存至: {summary_path}")
    print(f"详细结果已保存至: {detail_path}")
    print(f"(详细文件包含 {len(df_detail)} 条记录: 8配置 × {runs}次)")