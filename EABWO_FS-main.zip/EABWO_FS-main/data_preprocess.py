import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
import warnings
import os

warnings.filterwarnings('ignore')


# ------------------- 1. 通用父类：BaseDataPreprocessor（统一封装通用逻辑） -------------------
class BaseDataPreprocessor:
    """
    所有数据集预处理的通用父类
    封装跨数据集的通用功能：数据加载、列名标准化、缺失值填充、数据保存
    """

    def __init__(self):
        # 存储中间数据和最终结果
        self.raw_data = None
        self.final_processed_data = None
        self.clean_redundant_data = None
        self.labeled_data = None

    def _normalize_column_names(self, df):
        """通用：列名标准化（统一小写、下划线，消除格式差异）"""
        df.columns = df.columns.str.strip() \
            .str.lower() \
            .str.replace(' ', '_') \
            .str.replace('.', '_') \
            .str.replace('/', '_')
        return df

    def load_data(self, input_file_path, low_memory=False, encoding='utf-8'):
        """通用：加载数据集（适配大文件，避免类型推断错误）"""
        try:
            self.raw_data = pd.read_csv(
                input_file_path,
                low_memory=low_memory,
                encoding=encoding
            )
            print(f"✅ 数据集加载成功，原始形状：{self.raw_data.shape}")
            # 列名标准化
            self.raw_data = self._normalize_column_names(self.raw_data)
        except Exception as e:
            print(f"❌ 数据集加载失败：{e}")
            raise

    def fill_missing_values(self, df, fill_method='median'):
        """通用：填充数值特征缺失值（默认中位数，抗极值干扰）"""
        numeric_cols = df.select_dtypes(include=['float64', 'int64']).columns
        if fill_method == 'median':
            df[numeric_cols] = df[numeric_cols].fillna(df[numeric_cols].median())
        elif fill_method == 'mean':
            df[numeric_cols] = df[numeric_cols].fillna(df[numeric_cols].mean())
        return df

    def save_data(self, output_file_path):
        """通用：保存预处理后的数据（自动创建输出目录，避免报错）"""
        if self.final_processed_data is None:
            raise ValueError("❌ 请先执行preprocess()完成数据预处理")

        # 自动创建输出目录
        output_dir = os.path.dirname(output_file_path)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)
            print(f"✅ 已自动创建输出目录：{output_dir}")

        # 保存CSV文件
        self.final_processed_data.to_csv(output_file_path, index=False, encoding='utf-8')
        print(f"\n🎉 预处理数据已保存至：{output_file_path}")

    # 抽象方法（由子类实现个性化逻辑，强制子类规范）
    def remove_redundant_columns(self):
        raise NotImplementedError("子类必须实现remove_redundant_columns方法")

    def clean_and_encode_labels(self):
        raise NotImplementedError("子类必须实现clean_and_encode_labels方法")

    def encode_non_numeric_features(self):
        raise NotImplementedError("子类必须实现encode_non_numeric_features方法")

    def preprocess(self, input_file_path):
        raise NotImplementedError("子类必须实现preprocess方法")


# ------------------- 2. 子类：AndroidMalwarePreprocessor（Android恶意软件数据集） -------------------
class AndroidMalwarePreprocessor(BaseDataPreprocessor):
    """
    Android恶意软件数据集专用预处理子类
    继承父类通用逻辑，实现该数据集的个性化处理（标签映射、冗余列等）
    """

    def __init__(self, label_map=None, redundant_cols=None):
        super().__init__()  # 调用父类初始化方法

        # Android数据集默认标签映射（固定Benign=0）
        self.default_label_map = {
            'Benign': 0,
            'Android_Adware': 1,
            'Android_Scareware': 2,
            'Android_SMS_Malware': 3
        }

        # Android数据集默认冗余列清单
        self.default_redundant_cols = [
            # 五元组核心列
            'Flow ID', 'Source IP', 'Source Port', 'Destination IP', 'Destination Port', 'Protocol',
            # 时间戳列
            'Timestamp',
            # 特有重复列
            'Fwd Header Length.1', 'Bwd Header Length.1',
            # 计算衍生列
            'Flow Bytes/s', 'Flow Packets/s', 'Fwd Packets/s', 'Bwd Packets/s',
            'Down/Up Ratio', 'Average Packet Size', 'Packet Length Variance',
            'Fwd Average Packet Size', 'Bwd Average Packet Size', 'Packet Length Std',
            # 极低区分度列
            'CWE Flag Count', 'ECE Flag Count', 'URG Flag Count', 'PSH Flag Count',
            # 无效列
            'Unnamed: 0', 'Unnamed: 0.1'
        ]

        # 优先使用用户自定义参数，无则使用默认值
        self.label_map = label_map if label_map is not None else self.default_label_map
        self.redundant_cols = redundant_cols if redundant_cols is not None else self.default_redundant_cols

    def set_label_map(self, new_label_map):
        """动态更新标签映射（灵活适配不同标签格式）"""
        self.label_map = new_label_map
        print(f"✅ 已更新Android数据集标签映射：{self.label_map}")

    def set_redundant_cols(self, new_redundant_cols):
        """动态更新冗余列清单（适配数据集不同版本）"""
        self.redundant_cols = new_redundant_cols
        print(f"✅ 已更新Android数据集冗余列清单，共{len(self.redundant_cols)}个列")

    def remove_redundant_columns(self):
        """个性化：移除Android数据集专属冗余列"""
        if self.raw_data is None:
            raise ValueError("❌ 请先调用load_data()加载数据集")

        self.clean_redundant_data = self.raw_data.copy()
        # 标准化冗余列名，与数据集列名格式对齐
        redundant_cols_normalized = [
            col.strip().lower().replace(' ', '_').replace('.', '_').replace('/', '_')
            for col in self.redundant_cols
        ]
        # 筛选实际存在的冗余列
        existing_redundant = [col for col in redundant_cols_normalized if col in self.clean_redundant_data.columns]

        if existing_redundant:
            self.clean_redundant_data = self.clean_redundant_data.drop(columns=existing_redundant)
            print(
                f"\n🗑️ Android数据集已移除{len(existing_redundant)}个冗余列，数据形状：{self.clean_redundant_data.shape}")
        else:
            print("\n✅ Android数据集无需要移除的冗余列")

    def clean_and_encode_labels(self):
        """个性化：清洗并编码Android数据集标签（确保Benign=0）"""
        if self.clean_redundant_data is None:
            raise ValueError("❌ 请先调用remove_redundant_columns()移除冗余列")

        self.labeled_data = self.clean_redundant_data.copy()
        # 标签格式清洗
        self.labeled_data['label'] = self.labeled_data['label'].astype(str).str.strip().str.replace(' ', '_')
        # 统一大小写后映射，避免大小写差异导致映射失败
        label_map_lower = {k.lower(): v for k, v in self.label_map.items()}
        self.labeled_data['label'] = self.labeled_data['label'].str.lower().map(label_map_lower)

        # 删除标签缺失行
        missing_label_count = self.labeled_data['label'].isna().sum()
        if missing_label_count > 0:
            self.labeled_data = self.labeled_data.dropna(subset=['label'])
            print(f"\n🗑️ Android数据集删除{missing_label_count}条标签缺失行")

        # 打印标签分布
        print("\n📊 Android数据集标签分布：")
        for label_name, code in self.label_map.items():
            count = self.labeled_data[self.labeled_data['label'] == code].shape[0]
            print(f"   - {label_name} → 编码{code}：{count} 条")

    def encode_non_numeric_features(self):
        """个性化：编码Android数据集非数值特征"""
        if self.labeled_data is None:
            raise ValueError("❌ 请先调用clean_and_encode_labels()编码标签")

        self.final_processed_data = self.labeled_data.copy()
        le = LabelEncoder()
        # 筛选非数值特征（排除标签列）
        non_numeric_cols = [
            col for col in self.final_processed_data.columns
            if self.final_processed_data[col].dtype == 'object' and col != 'label'
        ]

        # 逐个编码非数值特征
        for col in non_numeric_cols:
            self.final_processed_data[col] = self.final_processed_data[col].fillna('Unknown').astype(str).str.strip()
            self.final_processed_data[col] = le.fit_transform(self.final_processed_data[col])
            print(f"✅ Android数据集特征{col}编码完成（类别数：{len(le.classes_)}）")

        if not non_numeric_cols:
            print("\n✅ Android数据集无需要编码的非数值特征")

        # 调用父类通用方法填充缺失值
        self.final_processed_data = self.fill_missing_values(self.final_processed_data)
        self.final_processed_data = self.final_processed_data.dropna(axis=0)
        print(f"\n🧹 Android数据集特征编码完成，清洗后数据形状：{self.final_processed_data.shape}")

    def preprocess(self, input_file_path):
        """个性化：Android数据集完整预处理流程（通用+个性化结合）"""
        print("=" * 60)
        print("开始执行Android恶意软件数据集预处理流程")
        print("=" * 60)
        # 调用父类通用方法
        self.load_data(input_file_path, low_memory=False)
        # 调用子类个性化方法
        self.remove_redundant_columns()
        self.clean_and_encode_labels()
        self.encode_non_numeric_features()
        print("=" * 60)
        print("Android恶意软件数据集预处理流程执行完毕")
        print("=" * 60)


# ------------------- 3. 子类：CICMal2017Preprocessor（CICMal2017数据集） -------------------
class CICMal2017Preprocessor(BaseDataPreprocessor):
    """CICMal2017数据集专用子类（继承通用父类，实现个性化逻辑）"""

    def __init__(self, label_map=None, redundant_cols=None):
        super().__init__()
        # CICMal2017默认标签映射（个性化）
        self.default_label_map = {
            "BENIGN": 0,
            "ADWARE": 1,
            "RANSOMWARE": 2,
            "SCAREWARE": 3,
            "SMSMALWARE": 4
        }
        # CICMal2017默认冗余列（个性化，可根据实际调整）
        self.default_redundant_cols = [
            'Flow ID', 'Source IP', 'Source Port', 'Destination IP', 'Destination Port',
            'Timestamp', 'Unnamed: 0'
        ]
        # 参数初始化
        self.label_map = label_map if label_map is not None else self.default_label_map
        self.redundant_cols = redundant_cols if redundant_cols is not None else self.default_redundant_cols

    # 实现父类抽象方法（CICMal2017个性化逻辑）
    def remove_redundant_columns(self):
        # 逻辑与Android子类一致，仅默认冗余列不同
        if self.raw_data is None:
            raise ValueError("❌ 请先加载数据集")
        self.clean_redundant_data = self.raw_data.copy()
        redundant_cols_normalized = [
            col.strip().lower().replace(' ', '_').replace('.', '_').replace('/', '_')
            for col in self.redundant_cols
        ]
        existing_redundant = [col for col in redundant_cols_normalized if col in self.clean_redundant_data.columns]
        if existing_redundant:
            self.clean_redundant_data = self.clean_redundant_data.drop(columns=existing_redundant)
            print(f"\n🗑️ CICMal2017已移除{len(existing_redundant)}个冗余列，数据形状：{self.clean_redundant_data.shape}")
        else:
            print("\n✅ CICMal2017无需要移除的冗余列")

    def clean_and_encode_labels(self):
        # CICMal2017标签清洗编码（个性化，保留原有逻辑）
        if self.clean_redundant_data is None:
            raise ValueError("❌ 请先移除冗余列")
        self.labeled_data = self.clean_redundant_data.copy()
        self.labeled_data['label'] = self.labeled_data['label'].astype(str).str.strip().str.upper()
        self.labeled_data['label'] = self.labeled_data['label'].map(self.label_map)
        missing_label_count = self.labeled_data['label'].isna().sum()
        if missing_label_count > 0:
            self.labeled_data = self.labeled_data.dropna(subset=['label'])
            print(f"\n🗑️ CICMal2017删除{missing_label_count}条标签缺失行")
        # 打印标签分布
        print("\n📊 CICMal2017标签分布：")
        for label, code in self.label_map.items():
            count = self.labeled_data[self.labeled_data['label'] == code].shape[0]
            print(f"   - {label} → 编码{code}：{count} 条")

    def encode_non_numeric_features(self):
        # 逻辑与Android子类一致，直接复用
        if self.labeled_data is None:
            raise ValueError("❌ 请先编码标签")
        self.final_processed_data = self.labeled_data.copy()
        le = LabelEncoder()
        non_numeric_cols = [col for col in self.final_processed_data.columns if
                            self.final_processed_data[col].dtype == 'object' and col != 'label']
        for col in non_numeric_cols:
            self.final_processed_data[col] = self.final_processed_data[col].fillna('Unknown').astype(str).str.strip()
            self.final_processed_data[col] = le.fit_transform(self.final_processed_data[col])
            print(f"✅ CICMal2017特征{col}编码完成（类别数：{len(le.classes_)}）")
        # 调用父类通用缺失值填充
        self.final_processed_data = self.fill_missing_values(self.final_processed_data)
        self.final_processed_data = self.final_processed_data.dropna(axis=0)
        print(f"\n🧹 CICMal2017特征编码完成，数据形状：{self.final_processed_data.shape}")

    def preprocess(self, input_file_path):
        # 完整流程（通用+个性化）
        print("=" * 60)
        print("开始执行CICMal2017数据集预处理")
        print("=" * 60)
        self.load_data(input_file_path, low_memory=False)
        self.remove_redundant_columns()
        self.clean_and_encode_labels()
        self.encode_non_numeric_features()
        print("=" * 60)
        print("CICMal2017预处理完成")
        print("=" * 60)


# ------------------- 4. 主程序：可选择批量处理数据集 -------------------
if __name__ == "__main__":
    # 配置待处理的数据集（按需添加/删除/修改，实现“选择处理”）
    # 注意：替换为你自己的实际文件路径
    dataset_configs = [
        {
            "type": "android",
            "input_path": "/data/users/trf/datasets/EABWO_FS/Android_Malware_Detection/Android_Malware.csv",
            "output_path": "/data/users/trf/datasets/EABWO_FS/Android_Malware_Detection_processed_dataset/Android_Malware_processed.csv"
        },
        {
            "type": "cic2017",
            "input_path": "/data/users/trf/datasets/EABWO_FS/CICMal2017/CICMal2017.csv",
            "output_path": "/data/users/trf/datasets/EABWO_FS/CICMal2017_processed_dataset/CICMal2017_processed.csv"
        }
    ]

    # 批量选择处理（无需修改核心逻辑，仅调整上面的配置即可）
    for config in dataset_configs:
        try:
            dataset_type = config["type"]
            input_path = config["input_path"]
            output_path = config["output_path"]

            print(f"\n{'*' * 100}")
            print(f"开始处理【{dataset_type}】数据集")
            print(f"{'*' * 100}")

            # 按需选择对应的预处理子类（统一接口，无感知切换）
            if dataset_type == "android":
                preprocessor = AndroidMalwarePreprocessor()
            elif dataset_type == "cic2017":
                preprocessor = CICMal2017Preprocessor()
            else:
                print(f"⚠️  不支持的数据集类型：{dataset_type}，跳过该数据集")
                continue

            # 统一接口调用，无需关注不同数据集的处理差异
            preprocessor.preprocess(input_path)
            preprocessor.save_data(output_path)

            print(f"\n{'*' * 100}")
            print(f"【{dataset_type}】数据集处理完成")
            print(f"{'*' * 100}\n")
        except Exception as e:
            print(f"❌ 处理【{config['type']}】数据集失败：{e}")
            continue