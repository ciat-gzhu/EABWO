"""
改进
1. 动态非线性平衡控制参数
2. 增强坠落行为策略
3. 失败参数检验变异机制

GPU加速版本 (CuPy)
"""

import cupy as cp
import numpy as np
import warnings
warnings.filterwarnings('ignore')


class EABWO:
    """
    参数:
        N: 种群大小
        T: 最大迭代次数
        lb: 搜索空间下界
        ub: 搜索空间上界
        dim: 问题维度
        fobj: 目标函数
        use_s1: 是否使用策略1(动态非线性平衡控制参数)
        use_s2: 是否使用策略2(增强坠落行为策略)
        use_s3: 是否使用策略3(失败参数检验变异机制)
    """
    
    def __init__(self, N, T, lb, ub, dim, fobj, use_s1=True, use_s2=True, use_s3=True):
        self.N = N
        self.T = T
        self.dim = dim
        self.fobj = fobj

        self.use_s1 = use_s1
        self.use_s2 = use_s2
        self.use_s3 = use_s3

        # 处理边界 (CuPy arrays)
        if isinstance(lb, (int, float)):
            self.lb = cp.ones(dim) * lb
            self.ub = cp.ones(dim) * ub
        else:
            self.lb = cp.array(lb, dtype=cp.float64)
            self.ub = cp.array(ub, dtype=cp.float64)
        
        # 初始化 (CuPy arrays)
        self.fit = cp.ones(N) * cp.inf
        self.newfit = cp.ones(N) * cp.inf
        self.Curve = cp.ones(T) * cp.inf
        self.kk_Record = cp.zeros(T)
        self.Counts_run = 0
        
        # 失败检验参数
        self.max_no_improvement = 10
        self.no_improvement_count = 0
        
        # 最优解
        self.fvalbest = float('inf')
        self.xposbest = None

        # 种群位置
        self.pos = None
        
        # Levy飞行预计算常量 (alpha=1.5)
        from scipy.special import gamma as _gamma
        _a = 1.5
        _num = _gamma(1 + _a) * np.sin(np.pi * _a / 2)
        _den = _gamma((1 + _a) / 2) * _a * (2 ** ((_a - 1) / 2))
        self._levy_sigma = (_num / _den) ** (1 / _a)
        
    def initialize_population(self):
        """初始化种群位置"""
        self.pos = cp.random.rand(self.N, self.dim) * (self.ub - self.lb) + self.lb
        
        for i in range(self.N):
            self.fit[i] = self.fobj(self.pos[i, :])
            self.Counts_run += 1
        
        index = int(cp.argmin(self.fit))
        self.fvalbest = float(self.fit[index])
        self.xposbest = self.pos[index, :].copy()
    
    def levy_flight(self, dim):
        """Levy飞行策略"""
        alpha = 1.5
        
        u = cp.random.randn(dim) * self._levy_sigma
        v = cp.random.randn(dim)
        S = u / (cp.abs(v) ** (1 / alpha))
        
        KD = 0.05
        LevyFlight = KD * S
        
        return LevyFlight
    
    def boundary_check(self, pos):
        """边界检查"""
        pos = cp.clip(pos, self.lb, self.ub)
        return pos
    
    def calculate_kk(self, t):
        """
        改进策略1: 计算动态非线性平衡控制参数 kk
        
        公式: kk = 1.5×sin(2πt/T)×tanh(2t/T-1) + 0.75×cos(4π(t/T)²) + 0.5
        """
        term1 = 1.5 * cp.sin(2 * cp.pi * t / self.T) * cp.tanh(2 * t / self.T - 1)
        term2 = 0.75 * cp.cos(4 * cp.pi * (t / self.T) ** 2)
        kk = term1 + term2 + 0.5
        
        return float(kk)
    
    def exploration_phase(self, i, RJ):
        """
        探索阶段: 白鲸游泳行为
        """
        r1 = float(cp.random.rand())
        r2 = float(cp.random.rand())
        
        newpos = self.pos[i, :].copy()
        
        if self.dim <= self.N / 5:
            params = cp.random.choice(self.dim, 2, replace=False)
            p0, p1 = int(params[0]), int(params[1])
            newpos[p0] = self.pos[i, p0] + \
                (self.pos[RJ, p0] - self.pos[i, p1]) * (r1 + 1) * cp.sin(r2 * 2 * cp.pi)
            newpos[p1] = self.pos[i, p1] + \
                (self.pos[RJ, p0] - self.pos[i, p1]) * (r1 + 1) * cp.cos(r2 * 2 * cp.pi)
        else:
            params = cp.random.permutation(self.dim)
            for j in range(self.dim // 2):
                newpos[params[2*j]] = self.pos[i, params[2*j]] + \
                    (self.pos[RJ, params[0]] - self.pos[i, params[2*j]]) * (r1 + 1) * cp.sin(r2 * 2 * cp.pi)
                newpos[params[2*j+1]] = self.pos[i, params[2*j+1]] + \
                    (self.pos[RJ, params[0]] - self.pos[i, params[2*j+1]]) * (r1 + 1) * cp.cos(r2 * 2 * cp.pi)
        
        return newpos
    
    def exploitation_phase(self, i, RJ, t):
        """
        开发阶段: 白鲸捕食行为
        """
        r3 = float(cp.random.rand())
        r4 = float(cp.random.rand())
        C1 = 2 * r4 * (1 - t / self.T)
        
        LevyFlight = self.levy_flight(self.dim)
        
        newpos = r3 * self.xposbest - r4 * self.pos[i, :] + \
                 C1 * LevyFlight * (self.pos[RJ, :] - self.pos[i, :])
        
        return newpos
    
    def whale_fall_original(self, i, RJ, t, WF):
        """原始鲸鱼坠落行为"""
        r5 = float(cp.random.rand())
        r6 = float(cp.random.rand())
        r7 = float(cp.random.rand())
        
        C2 = 2 * self.N * WF
        stepsize2 = r7 * (self.ub - self.lb) * cp.exp(cp.float64(-C2 * t / self.T))
        
        newpos = (r5 * self.pos[i, :] - r6 * self.pos[RJ, :]) + stepsize2
        
        return newpos
    
    def whale_fall_enhanced(self, i, t):
        """
        改进策略2: 增强鲸鱼坠落行为
        """
        F = float(cp.cos(1 - 2 * cp.pi * t / self.T) * cp.random.rand())
        StepSize = self.xposbest - self.pos[i, :]
        newpos = self.pos[i, :] + F * StepSize
        
        return newpos
    
    def mutation_mechanism(self, t):
        """
        改进策略3: 失败参数检验变异机制
        """
        newpos = cp.zeros((self.N, self.dim))
        fitness = cp.zeros(self.N)
        
        for i in range(self.N):
            step_size = (float(cp.random.rand()) * t / self.T) * cp.random.randn(self.dim)
            mutation_vector = step_size * self.pos[i, :]
            newpos[i, :] = self.xposbest + float(cp.random.rand()) * mutation_vector
            newpos[i, :] = self.boundary_check(newpos[i, :])
        
        for i in range(self.N):
            fitness[i] = self.fobj(newpos[i, :])
            self.Counts_run += 1
            
            if float(fitness[i]) < self.fvalbest:
                self.fvalbest = float(fitness[i])
                self.xposbest = newpos[i, :].copy()
            
            if float(fitness[i]) < float(self.fit[i]):
                self.pos[i, :] = newpos[i, :].copy()
                self.fit[i] = fitness[i]
        
        return newpos, fitness
    
    def optimize(self, verbose=True):
        """
        执行优化过程
        
        返回:
            fvalbest: 最优适应度值
            xposbest: 最优解位置
            Curve: 收敛曲线
        """
        self.initialize_population()
        t = 1
        if verbose:
            print(f"EABWO优化开始 (GPU: CuPy)")
            print(f"种群大小: {self.N}, 迭代次数: {self.T}, 维度: {self.dim}")
        
        # 主循环
        while t <= self.T:
            newpos = self.pos.copy()
            
            WF = 0.1 - 0.05 * (t / self.T)
            
            # 策略1开关控制
            if self.use_s1:
                kk = self.calculate_kk(t)
            else:
                kk = 1.0 - (t / self.T)

            # 第一阶段: 探索或开发
            for i in range(self.N):
                RJ = int(cp.random.randint(0, self.N))
                while RJ == i:
                    RJ = int(cp.random.randint(0, self.N))
                
                if kk > 0.5:
                    newpos[i, :] = self.exploration_phase(i, RJ)
                else:
                    newpos[i, :] = self.exploitation_phase(i, RJ, t)
                
                newpos[i, :] = self.boundary_check(newpos[i, :])
                
                self.newfit[i] = self.fobj(newpos[i, :])
                self.Counts_run += 1
                
                if self.newfit[i] < self.fit[i]:
                    self.pos[i, :] = newpos[i, :].copy()
                    self.fit[i] = self.newfit[i]
            
            # 第二阶段: 鲸鱼坠落行为
            for i in range(self.N):
                if (not self.use_s2) or (kk <= WF):
                    RJ = int(cp.random.randint(0, self.N))
                    while RJ == i:
                        RJ = int(cp.random.randint(0, self.N))
                    newpos[i, :] = self.whale_fall_original(i, RJ, t, WF)
                else:
                    newpos[i, :] = self.whale_fall_enhanced(i, t)

                newpos[i, :] = self.boundary_check(newpos[i, :])
                
                self.newfit[i] = self.fobj(newpos[i, :])
                self.Counts_run += 1
                
                if self.newfit[i] < self.fit[i]:
                    self.pos[i, :] = newpos[i, :].copy()
                    self.fit[i] = self.newfit[i]
            
            # 更新全局最优解
            current_best_score = float(cp.min(self.fit))
            idx = int(cp.argmin(self.fit))
            
            if current_best_score < self.fvalbest:
                self.fvalbest = current_best_score
                self.xposbest = self.pos[idx, :].copy()
                self.no_improvement_count = 0
            else:
                self.no_improvement_count += 1
            
            # 改进策略3: 失败参数检验变异机制
            if self.use_s3 and (self.no_improvement_count >= self.max_no_improvement):
                newpos, fitness = self.mutation_mechanism(t)
                self.no_improvement_count = 0
            
            # 记录收敛曲线
            self.kk_Record[t-1] = kk
            self.Curve[t-1] = self.fvalbest

            if verbose and (t % 10 == 0 or t == 1):
                print(f"迭代 {t}/{self.T}, 最优适应度: {self.fvalbest:.6f}")
            
            t += 1
        
        if verbose:
            print(f"\n优化完成! 函数调用次数: {self.Counts_run}")
            print(f"最优适应度值: {self.fvalbest:.6f}")
        
        # 返回时转为numpy供调用方使用
        return self.fvalbest, cp.asnumpy(self.xposbest), cp.asnumpy(self.Curve)


def eabwo_optimize(N, T, lb, ub, dim, fobj, verbose=True):
    """
    参数:
        N: 种群大小
        T: 最大迭代次数
        lb: 搜索空间下界
        ub: 搜索空间上界
        dim: 问题维度
        fobj: 目标函数
        verbose: 是否显示优化过程
    
    返回:
        fvalbest: 最优适应度值
        xposbest: 最优解位置
        Curve: 收敛曲线
    """
    optimizer = EABWO(N, T, lb, ub, dim, fobj)
    return optimizer.optimize(verbose=verbose)


if __name__ == "__main__":
    def sphere_function(x):
        return float(cp.sum(x ** 2))
    
    N = 30
    T = 100
    dim = 10
    lb = -100
    ub = 100
    
    print("=" * 60)
    print("EABWO算法测试 - Sphere函数 (GPU版本)")
    print("=" * 60)
    
    fvalbest, xposbest, Curve = eabwo_optimize(N, T, lb, ub, dim, sphere_function)
    
    print(f"\n最优解: {xposbest}")
    print(f"最优值: {fvalbest}")