"""
BWO: Beluga Whale Optimization
原始论文: Zhong C, Li G, Meng Z. Beluga whale optimization: A novel
          nature-inspired metaheuristic algorithm[J].
          Knowledge-Based Systems, 2022.

本文件为 BWO.m (MATLAB) 的忠实 Python 复现，接口与 EABWO.py 保持一致：
    optimizer = BWO(N, T, lb, ub, dim, fobj)
    fvalbest, xposbest, Curve = optimizer.optimize(verbose=True)
"""

import numpy as np
from scipy.special import gamma
import warnings

warnings.filterwarnings('ignore')


class BWO:
    """
    白鲸优化算法 (Beluga Whale Optimization)

    参数:
        N   : 种群大小
        T   : 最大迭代次数
        lb  : 搜索空间下界（标量或与 dim 等长的数组）
        ub  : 搜索空间上界（标量或与 dim 等长的数组）
        dim : 问题维度
        fobj: 目标函数（越小越好）
    """

    def __init__(self, N, T, lb, ub, dim, fobj):
        self.N    = N
        self.T    = T
        self.dim  = dim
        self.fobj = fobj

        # 边界统一处理为数组
        if isinstance(lb, (int, float)):
            self.lb = np.ones(dim) * lb
            self.ub = np.ones(dim) * ub
        else:
            self.lb = np.array(lb, dtype=float)
            self.ub = np.array(ub, dtype=float)

        # 运行状态
        self.fit       = np.inf * np.ones(N)
        self.newfit    = np.inf * np.ones(N)
        self.Curve     = np.inf * np.ones(T)
        self.Counts_run = 0

        # 最优解
        self.fvalbest  = np.inf
        self.xposbest  = None

    # ──────────────────────────────────────────────────────────
    # 工具方法
    # ──────────────────────────────────────────────────────────
    def _boundary_check(self, pos):
        """clip 边界处理，等价于 MATLAB 中的 Flag4ub/Flag4lb 逻辑"""
        return np.clip(pos, self.lb, self.ub)

    def _levy_flight(self):
        """Levy 飞行，与 BWO.m 及 EABWO.py 保持相同公式"""
        alpha = 1.5
        num   = gamma(1 + alpha) * np.sin(np.pi * alpha / 2)
        den   = gamma((1 + alpha) / 2) * alpha * (2 ** ((alpha - 1) / 2))
        sigma = (num / den) ** (1 / alpha)

        u = np.random.randn(self.dim) * sigma
        v = np.random.randn(self.dim)
        S = u / (np.abs(v) ** (1 / alpha))

        KD = 0.05
        return KD * S

    # ──────────────────────────────────────────────────────────
    # 初始化种群
    # ──────────────────────────────────────────────────────────
    def _initialize(self):
        self.pos = (np.random.rand(self.N, self.dim)
                    * (self.ub - self.lb) + self.lb)

        for i in range(self.N):
            self.fit[i] = self.fobj(self.pos[i, :])
            self.Counts_run += 1

        idx = np.argmin(self.fit)
        self.fvalbest = self.fit[idx]
        self.xposbest = self.pos[idx, :].copy()

    # ──────────────────────────────────────────────────────────
    # 探索阶段（对应 MATLAB kk(i) > 0.5 分支）
    # ──────────────────────────────────────────────────────────
    def _exploration(self, i, RJ, r1, r2):
        """
        同步/镜像游泳行为
        低维: 随机选 2 个维度更新
        高维: 对所有维度分对更新（下标写入顺序，读取用置换下标）
        注: MATLAB sin/cos 用角度制 r2*360°，Python 转为 r2*2π
        """
        newpos = self.pos[i, :].copy()

        if self.dim <= self.N / 5:
            # 低维：随机选 2 个不重复维度
            params = np.random.choice(self.dim, 2, replace=False)
            p0, p1 = params[0], params[1]
            diff = (self.pos[RJ, p0] - self.pos[i, p1]) * (r1 + 1)
            newpos[p0] = self.pos[i, p0] + diff * np.sin(r2 * 2 * np.pi)
            newpos[p1] = self.pos[i, p1] + diff * np.cos(r2 * 2 * np.pi)
        else:
            # 高维：全维度随机置换后分对处理
            params = np.random.permutation(self.dim)   # 置换下标
            half   = self.dim // 2
            for j in range(half):
                # 读取时用置换下标，写入时用顺序下标（忠实对应 MATLAB）
                p_read_odd  = params[2 * j]
                p_read_even = params[2 * j + 1]
                diff_odd  = (self.pos[RJ, params[0]] - self.pos[i, p_read_odd])  * (r1 + 1)
                diff_even = (self.pos[RJ, params[0]] - self.pos[i, p_read_even]) * (r1 + 1)
                newpos[2 * j]     = self.pos[i, p_read_odd]  + diff_odd  * np.sin(r2 * 2 * np.pi)
                newpos[2 * j + 1] = self.pos[i, p_read_even] + diff_even * np.cos(r2 * 2 * np.pi)

        return newpos

    # ──────────────────────────────────────────────────────────
    # 开发阶段（对应 MATLAB else 分支）
    # ──────────────────────────────────────────────────────────
    def _exploitation(self, i, RJ, t):
        """
        捕食行为，结合 Levy 飞行
        newpos = r3*xbest - r4*pos_i + C1*LevyFlight*(pos_RJ - pos_i)
        """
        r3 = np.random.rand()
        r4 = np.random.rand()
        C1 = 2 * r4 * (1 - t / self.T)
        LF = self._levy_flight()
        return (r3 * self.xposbest
                - r4 * self.pos[i, :]
                + C1 * LF * (self.pos[RJ, :] - self.pos[i, :]))

    # ──────────────────────────────────────────────────────────
    # 鲸鱼坠落（对应 MATLAB 第二个 for 循环）
    # ──────────────────────────────────────────────────────────
    def _whale_fall(self, i, RJ, t, WF):
        """
        stepsize2 = r7*(ub-lb)*exp(-C2*t/T)
        newpos    = (r5*pos_i - r6*pos_RJ) + stepsize2
        """
        r5 = np.random.rand()
        r6 = np.random.rand()
        r7 = np.random.rand()
        C2 = 2 * self.N * WF
        stepsize2 = r7 * (self.ub - self.lb) * np.exp(-C2 * t / self.T)
        return r5 * self.pos[i, :] - r6 * self.pos[RJ, :] + stepsize2

    # ──────────────────────────────────────────────────────────
    # 主优化循环
    # ──────────────────────────────────────────────────────────
    def optimize(self, verbose=True):
        """
        返回:
            fvalbest : 最优适应度值
            xposbest : 最优解位置向量
            Curve    : 收敛曲线（长度 = T）
        """
        self._initialize()

        if verbose:
            print(f"BWO 优化开始  种群={self.N}  迭代={self.T}  维度={self.dim}")

        for t in range(1, self.T + 1):
            newpos = self.pos.copy()

            # 鲸鱼坠落概率（随迭代线性衰减）
            WF = 0.1 - 0.05 * (t / self.T)

            # 每个个体独立的 kk 值（N×1），控制探索/开发倾向
            kk = (1 - 0.5 * t / self.T) * np.random.rand(self.N)

            # ── 第一阶段：探索 or 开发 ───────────────────────
            for i in range(self.N):
                # 随机选一个不同个体 RJ（对应 MATLAB ceil(N*rand)，1-based→0-based）
                RJ = np.random.randint(0, self.N)
                while RJ == i:
                    RJ = np.random.randint(0, self.N)

                if kk[i] > 0.5:
                    r1 = np.random.rand()
                    r2 = np.random.rand()
                    newpos[i, :] = self._exploration(i, RJ, r1, r2)
                else:
                    newpos[i, :] = self._exploitation(i, RJ, t)

                newpos[i, :] = self._boundary_check(newpos[i, :])

                self.newfit[i] = self.fobj(newpos[i, :])
                self.Counts_run += 1

                if self.newfit[i] < self.fit[i]:
                    self.pos[i, :] = newpos[i, :].copy()
                    self.fit[i]    = self.newfit[i]

            # ── 第二阶段：鲸鱼坠落 ───────────────────────────
            for i in range(self.N):
                if kk[i] <= WF:
                    RJ = np.random.randint(0, self.N)
                    newpos[i, :] = self._whale_fall(i, RJ, t, WF)
                    newpos[i, :] = self._boundary_check(newpos[i, :])

                    self.newfit[i] = self.fobj(newpos[i, :])
                    self.Counts_run += 1

                    if self.newfit[i] < self.fit[i]:
                        self.pos[i, :] = newpos[i, :].copy()
                        self.fit[i]    = self.newfit[i]

            # ── 更新全局最优 ─────────────────────────────────
            idx  = np.argmin(self.fit)
            fval = self.fit[idx]
            if fval < self.fvalbest:
                self.fvalbest = fval
                self.xposbest = self.pos[idx, :].copy()

            self.Curve[t - 1] = self.fvalbest

            if verbose and (t % 10 == 0 or t == 1):
                print(f"  迭代 {t:>3}/{self.T}  最优适应度: {self.fvalbest:.6f}")

        if verbose:
            print(f"\nBWO 完成  函数调用次数: {self.Counts_run}")
            print(f"最优适应度: {self.fvalbest:.6f}")

        return self.fvalbest, self.xposbest, self.Curve
