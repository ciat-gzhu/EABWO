#!/bin/bash
D=/data3/trf/dataset/Edge-IIoTset/processed_enhance_edge.csv
S=/data3/trf/dataset/ablation
CUDA_VISIBLE_DEVICES=0 python run_ablation_cuml.py --dataset $D --save_dir $S --nshards 3 --shard 0 > shard0.log 2>&1 &
CUDA_VISIBLE_DEVICES=1 python run_ablation_cuml.py --dataset $D --save_dir $S --nshards 3 --shard 1 > shard1.log 2>&1 &
CUDA_VISIBLE_DEVICES=2 python run_ablation_cuml.py --dataset $D --save_dir $S --nshards 3 --shard 2 > shard2.log 2>&1 &
wait
python run_ablation_cuml.py --dataset $D --save_dir $S --merge
echo "===== 全部完成 ====="
