"""
1. EABWO 特征子集搜索
2. XGBoost / cuML RandomForest 评估器
特征选择通过二进制编码实现，1表示选择该特征，0表示不选择

全GPU加速版本 (CuPy + XGBoost GPU + cuML)
"""

import numpy as np
import cupy as cp
import pandas as pd
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import warnings
warnings.filterwarnings('ignore')

try:
    from cuml.ensemble import RandomForestClassifier as RandomForestClassifierGPU
    CUML_AVAILABLE = True
except ImportError:
    CUML_AVAILABLE = False
    RandomForestClassifierGPU = None

XGB_IMPORT_ERROR = None
try:
    import xgboost as xgb
    XGBOOST_AVAILABLE = True
    XGB_VERSION = tuple(int(v) for v in xgb.__version__.split('.')[:2])
except Exception as e:
    XGBOOST_AVAILABLE = False
    XGB_IMPORT_ERROR = e
    XGB_VERSION = (0, 0)
    print(f"警告: XGBoost 不可用 ({type(e).__name__}: {e})")

from EABWO import EABWO


class FeatureSelectionEABWO:
    """
    基于EABWO和XGBoost的特征选择类
    
    参数:
        n_population: 种群大小 (默认30)
        n_iterations: 最大迭代次数 (默认50)
        alpha: 特征数量惩罚系数 (默认0.01，越大越倾向于选择更少特征)
        test_size: 测试集比例 (默认0.3)
        random_state: 随机种子 (默认42)
        use_xgboost: 是否使用XGBoost (默认True)
        cv_folds: 交叉验证折数 (默认3)
        xgb_params: XGBoost参数字典
    """
    
    def __init__(self, n_population=30, n_iterations=50, alpha=0.01, 
                 test_size=0.3, random_state=42, use_xgboost=True, 
                 cv_folds=3, xgb_params=None, use_s1=True, use_s2=True, use_s3=True):
        
        self.n_population = n_population
        self.n_iterations = n_iterations
        self.alpha = alpha
        self.test_size = test_size
        self.random_state = random_state
        if use_xgboost and not XGBOOST_AVAILABLE:
            raise RuntimeError(
                "消融实验要求 XGBoost 评估器，但其导入失败，已拒绝降级为随机森林。原因: "
                f"{type(XGB_IMPORT_ERROR).__name__}: {XGB_IMPORT_ERROR}"
            )
        self.use_xgboost = use_xgboost and XGBOOST_AVAILABLE
        self.cv_folds = cv_folds
        
        self.use_s1 = use_s1
        self.use_s2 = use_s2
        self.use_s3 = use_s3

        if xgb_params is None:
            self.xgb_params = {
                'max_depth': 6,
                'learning_rate': 0.1,
                'n_estimators': 100,
                'objective': 'binary:logistic',
                'random_state': random_state,
                'verbosity': 0
            }
            if XGBOOST_AVAILABLE:
                if XGB_VERSION >= (2, 0):
                    self.xgb_params['tree_method'] = 'hist'
                    self.xgb_params['device'] = 'cuda'
                else:
                    self.xgb_params['tree_method'] = 'gpu_hist'
        else:
            self.xgb_params = xgb_params
        
        # 数据相关 (X_train/X_test为cupy数组, y_train/y_test保持numpy)
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.n_features = None
        self.n_classes = None
        self.y_train_gpu = None
        self.cv_splits = None
        
        # 结果相关
        self.best_features = None
        self.best_fitness = None
        self.convergence_curve = None
        self.selected_feature_indices = None
        
    def load_data(self, filepath_or_dataframe, label_column=-1, normalize=True, max_samples=None):
        """
        加载数据
        """
        if isinstance(filepath_or_dataframe, str):
            print(f"正在加载数据: {filepath_or_dataframe}")
            df = pd.read_csv(filepath_or_dataframe)
        else:
            df = filepath_or_dataframe.copy()
        
        print(f"数据形状: {df.shape}")
        
        if isinstance(label_column, int):
            if label_column == -1:
                label_column = df.columns[-1]
            else:
                label_column = df.columns[label_column]
        
        X = df.drop(columns=[label_column]).values
        y = df[label_column].values
        
        le = LabelEncoder()
        y = le.fit_transform(y)
        
        if max_samples is not None and max_samples > 0 and len(y) > max_samples:
            print(f"下采样: {len(y)} -> {max_samples} (分层抽样, 保持类别比例)")
            X, _, y, _ = train_test_split(X, y, train_size=max_samples, stratify=y, random_state=self.random_state)

        self.n_classes = len(np.unique(y))
        
        print(f"特征数量: {X.shape[1]}")
        print(f"样本数量: {X.shape[0]}")
        print(f"类别数量: {self.n_classes}")
        print(f"类别分布: {np.bincount(y)}")
        
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X, y, test_size=self.test_size, random_state=self.random_state, stratify=y
        )
        
        if normalize:
            scaler = StandardScaler()
            self.X_train = scaler.fit_transform(self.X_train)
            self.X_test = scaler.transform(self.X_test)
        
        self.X_train = cp.asarray(self.X_train, dtype=cp.float64)
        self.X_test = cp.asarray(self.X_test, dtype=cp.float64)
        self.y_train_gpu = cp.asarray(self.y_train)

        # 每次加载数据只划分一次，所有候选特征子集复用相同的3折索引。
        skf = StratifiedKFold(
            n_splits=self.cv_folds, shuffle=True, random_state=self.random_state
        )
        self.cv_splits = [
            (cp.asarray(train_idx), cp.asarray(val_idx))
            for train_idx, val_idx in skf.split(
                np.zeros(len(self.y_train), dtype=np.uint8), self.y_train
            )
        ]
        
        self.n_features = X.shape[1]
        
        print(f"训练集大小: {self.X_train.shape}")
        print(f"测试集大小: {self.X_test.shape}")
        
    def _binary_encode(self, position):
        """
        将连续位置编码为二进制特征选择向量
        """
        position = cp.asarray(position)
        sigmoid = 1 / (1 + cp.exp(-position))
        binary = (sigmoid > 0.5).astype(cp.int32)
        
        if cp.sum(binary) == 0:
            idx = int(cp.random.randint(0, len(binary)))
            binary[idx] = 1
        
        return binary
    
    def _get_classifier(self):
        """获取GPU分类器"""
        if self.use_xgboost:
            if self.n_classes == 2:
                params = self.xgb_params.copy()
                params['objective'] = 'binary:logistic'
                return xgb.XGBClassifier(**params)
            else:
                params = self.xgb_params.copy()
                params['objective'] = 'multi:softmax'
                params['num_class'] = self.n_classes
                return xgb.XGBClassifier(**params)
        else:
            return RandomForestClassifierGPU(
                n_estimators=100,
                max_depth=10,
                random_state=self.random_state
            )
    
    def _fitness_function(self, position):
        """
        适应度函数 (全GPU版本)
        
        目标: 最小化分类错误率 + 特征数量惩罚
        
        公式: fitness = (1 - accuracy) + α × (n_selected / n_total)
        """
        binary_features = self._binary_encode(position)
        selected_indices = cp.where(binary_features == 1)[0]
        n_selected = len(selected_indices)
        
        if n_selected == 0:
            return 1.0 + self.alpha
        
        X_train_selected = self.X_train[:, selected_indices]
        
        try:
            scores = []
            for train_idx, val_idx in self.cv_splits:
                X_tr, X_val = X_train_selected[train_idx], X_train_selected[val_idx]
                y_tr = self.y_train_gpu[train_idx]
                y_val = self.y_train_gpu[val_idx]

                # XGBoost 和 cuML 均直接接收 GPU 数据，避免逐折往返复制。
                clf = self._get_classifier()
                clf.fit(X_tr, y_tr)
                y_pred = cp.asarray(clf.predict(X_val))
                scores.append(float(cp.mean(y_pred == y_val)))

            accuracy = np.mean(scores)
            
            error_rate = 1 - accuracy
            feature_penalty = self.alpha * (n_selected / self.n_features)
            fitness = error_rate + feature_penalty
            
        except Exception as e:
            print(f"评估失败: {e}")
            fitness = 1.0 + self.alpha
        
        return float(fitness)
    
    def fit(self, verbose=True):
        """
        执行特征选择
        """
        if self.X_train is None:
            raise ValueError("请先使用load_data()加载数据")
        
        print("\n" + "="*60)
        print("开始EABWO特征选择 (GPU: CuPy)")
        print("="*60)
        print(f"总特征数: {self.n_features}")
        print(f"种群大小: {self.n_population}")
        print(f"最大迭代次数: {self.n_iterations}")
        print(f"特征惩罚系数 α: {self.alpha}")
        print(f"分类器: {'XGBoost' if self.use_xgboost else 'RandomForest'}")
        print(f"策略1(动态非线性平衡): {'开启' if self.use_s1 else '关闭'}")
        print(f"策略2(增强坠落行为):   {'开启' if self.use_s2 else '关闭'}")
        print(f"策略3(失败变异机制):   {'开启' if self.use_s3 else '关闭'}")
        print("="*60 + "\n")
        
        optimizer = EABWO(
            N=self.n_population,
            T=self.n_iterations,
            lb=-6,
            ub=6,
            dim=self.n_features,
            fobj=self._fitness_function,
            use_s1=self.use_s1,
            use_s2=self.use_s2,
            use_s3=self.use_s3,
        )
       
        self.best_fitness, self.best_features, self.convergence_curve = optimizer.optimize(verbose=verbose)
        
        binary_features = cp.asnumpy(self._binary_encode(self.best_features))
        self.selected_feature_indices = np.where(binary_features == 1)[0]
        
        print("\n" + "="*60)
        print("特征选择完成!")
        print("="*60)
        print(f"选择的特征数量: {len(self.selected_feature_indices)} / {self.n_features}")
        print(f"特征选择率: {len(self.selected_feature_indices)/self.n_features*100:.2f}%")
        print(f"最优适应度: {self.best_fitness:.6f}")
        print(f"选择的特征索引: {self.selected_feature_indices.tolist()}")
        
        return self
    
    def evaluate(self, verbose=True):
        """
        在测试集上评估选择的特征
        """
        if self.selected_feature_indices is None:
            raise ValueError("请先执行fit()进行特征选择")
        
        sel_idx = cp.asarray(self.selected_feature_indices)
        X_train_selected = self.X_train[:, sel_idx]
        X_test_selected = self.X_test[:, sel_idx]
        
        clf = self._get_classifier()
        
        clf.fit(X_train_selected, self.y_train_gpu)
        # 仅将最终预测转回 CPU，供 sklearn 计算报告指标。
        y_pred = cp.asnumpy(cp.asarray(clf.predict(X_test_selected)))
        
        y_test_np = self.y_test if isinstance(self.y_test, np.ndarray) else cp.asnumpy(self.y_test)
        
        accuracy = accuracy_score(y_test_np, y_pred)
        
        average_method = 'binary' if self.n_classes == 2 else 'weighted'
        precision = precision_score(y_test_np, y_pred, average=average_method, zero_division=0)
        recall = recall_score(y_test_np, y_pred, average=average_method, zero_division=0)
        f1 = f1_score(y_test_np, y_pred, average=average_method, zero_division=0)
        
        results = {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1_score': f1,
            'n_selected_features': len(self.selected_feature_indices),
            'n_total_features': self.n_features,
            'feature_selection_rate': len(self.selected_feature_indices) / self.n_features,
            'selected_features': self.selected_feature_indices.tolist()
        }
        
        if verbose:
            print("\n" + "="*60)
            print("测试集评估结果")
            print("="*60)
            print(f"准确率 (Accuracy):  {accuracy:.4f}")
            print(f"精确率 (Precision): {precision:.4f}")
            print(f"召回率 (Recall):    {recall:.4f}")
            print(f"F1分数 (F1-Score):  {f1:.4f}")
            print(f"选择特征数量:       {len(self.selected_feature_indices)} / {self.n_features}")
            print(f"特征选择率:         {results['feature_selection_rate']*100:.2f}%")
            print("="*60 + "\n")
        
        return results
    
    def get_selected_data(self):
        """
        获取只包含选择特征的数据 (cupy数组)
        """
        if self.selected_feature_indices is None:
            raise ValueError("请先执行fit()进行特征选择")
        
        sel_idx = cp.asarray(self.selected_feature_indices)
        X_train_selected = self.X_train[:, sel_idx]
        X_test_selected = self.X_test[:, sel_idx]
        
        return X_train_selected, X_test_selected, self.y_train, self.y_test
    
    def plot_convergence(self, save_path=None):
        """
        绘制收敛曲线
        """
        try:
            import matplotlib.pyplot as plt
            
            plt.figure(figsize=(10, 6))
            plt.plot(range(1, len(self.convergence_curve) + 1), self.convergence_curve, 'b-', linewidth=2)
            plt.xlabel('迭代次数', fontsize=12)
            plt.ylabel('适应度值', fontsize=12)
            plt.title('EABWO特征选择收敛曲线', fontsize=14)
            plt.grid(True, alpha=0.3)
            plt.tight_layout()
            
            if save_path:
                plt.savefig(save_path, dpi=300, bbox_inches='tight')
                print(f"收敛曲线已保存至: {save_path}")
            
            plt.show()
        except ImportError:
            print("警告: matplotlib未安装，无法绘制收敛曲线")


def feature_selection_pipeline(data_path, label_column=-1, n_population=30, 
                               n_iterations=50, alpha=0.01, test_size=0.3,
                               random_state=42, use_xgboost=True, plot=False):
    """
    特征选择完整流程
    """
    fs = FeatureSelectionEABWO(
        n_population=n_population,
        n_iterations=n_iterations,
        alpha=alpha,
        test_size=test_size,
        random_state=random_state,
        use_xgboost=use_xgboost,
    )
    
    fs.load_data(data_path, label_column=label_column)
    
    fs.fit(verbose=True)
    
    results = fs.evaluate(verbose=True)
    
    if plot:
        fs.plot_convergence()
    
    return fs, results