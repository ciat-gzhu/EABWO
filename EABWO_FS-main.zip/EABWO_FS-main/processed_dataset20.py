import os
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import LabelEncoder
from datetime import datetime


def detect_useless_cols(df, feature_cols, missing_thresh=0.8, var_thresh=1e-6):
    """检测无意义列（含IP/端口等标识列）"""
    useless_cols = []
    # 1. 业务无意义列（IP/端口/时间戳等）
    business_useless = [
        'timestamp', 'src_ip', 'dst_ip', 'src_port', 'dst_port', 'protocol'
    ]
    business_useless = [col for col in business_useless if col in feature_cols]
    useless_cols.extend(business_useless)
    # 2. 剩余列检测
    remaining_cols = [col for col in feature_cols if col not in useless_cols]
    # 全常量列
    constant_cols = [col for col in remaining_cols if df[col].nunique() == 1]
    useless_cols.extend(constant_cols)
    # 缺失值过多列
    missing_cols = [col for col in remaining_cols if df[col].isnull().sum() / len(df) > missing_thresh]
    useless_cols.extend(missing_cols)
    # 低方差列
    df_filled = df[remaining_cols].fillna(0)
    low_var_cols = [col for col in remaining_cols if df_filled[col].var() < var_thresh]
    useless_cols.extend(low_var_cols)
    # 去重
    useless_cols = list(set(useless_cols))
    return useless_cols


def preprocess_single_csv(csv_path, all_feature_cols=None, label_encoder=None):
    """
    单文件预处理（独立归一化，适配特征差异）
    Args:
        csv_path: CSV路径
        all_feature_cols: 所有文件的公共特征列（统一特征维度）
        label_encoder: 全局标签编码器
    Returns:
        预处理后的DataFrame
    """
    # 1. 读取CSV
    df = pd.read_csv(csv_path, low_memory=False)
    print(f"\n处理文件：{os.path.basename(csv_path)}，原始形状：{df.shape}")

    # 2. 删除无关列
    df = df.drop(columns=['four_tuple'], errors='ignore')

    # 3. 分离特征和标签
    label_col = 'label' if 'label' in df.columns else None
    feature_cols = [col for col in df.columns if col != label_col]

    # 4. 检测并删除无意义列
    useless_cols = detect_useless_cols(df, feature_cols)
    if useless_cols:
        print(f"⚠️ 已删除无意义列：{useless_cols}")
        df = df.drop(columns=useless_cols)
        feature_cols = [col for col in feature_cols if col not in useless_cols]

    # 5. 特征列转为数值型
    for col in feature_cols:
        df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)

    # 6. 统一特征列（缺失特征补0）
    if all_feature_cols is not None:
        missing_features = [col for col in all_feature_cols if col not in df.columns]
        for col in missing_features:
            df[col] = 0  # 缺失特征补0
        df = df[all_feature_cols + ([label_col] if label_col else [])]

    # 7. 标签编码（核心修改：良性+恶意按子类型编码，无新增列）
    if label_col in df.columns:
        # 拆分标签，处理拆分后列数不足的情况（补Unknown），不落地为列
        split_result = df[label_col].str.split('_', expand=True)
        # 保证至少有两列（category和type），不足则补Unknown
        while split_result.shape[1] < 2:
            split_result[split_result.shape[1]] = 'Unknown'
        category = split_result.iloc[:, 0].fillna('Unknown')
        type_ = split_result.iloc[:, 1].fillna('Unknown')

        # 构建完整类型字符串（仅内存使用，不新增列）
        full_type_series = category + '_' + type_

        # 更新全局标签编码器（包含所有流量类型：良性+恶意）
        all_types_in_file = full_type_series.unique()
        new_types = [t for t in all_types_in_file if t not in label_encoder.classes_]
        if new_types:
            label_encoder.classes_ = np.append(label_encoder.classes_, new_types)

        # 对所有流量类型进行编码，直接赋值给Label列（无中间列）
        df['Label'] = label_encoder.transform(full_type_series)

        # 删除原始label列（无其他中间列需要删除）
        df = df.drop(columns=[label_col])

    # 8. 归一化（单文件独立归一化）
    feature_cols_final = [col for col in df.columns if col != 'Label']
    if feature_cols_final:
        scaler = MinMaxScaler()
        df[feature_cols_final] = scaler.fit_transform(df[feature_cols_final])

    print(f"✅ 预处理完成，最终形状：{df.shape}")
    return df


def batch_preprocess_csvs(csv_dir, output_path):
    """批量预处理（统一特征列+全局标签编码）"""
    # 自动创建输出目录
    output_dir = os.path.dirname(output_path)
    os.makedirs(output_dir, exist_ok=True)
    print(f"📁 输出目录：{output_dir}")

    # 1. 第一步：收集所有文件的特征列，确定公共特征
    all_feature_cols = []
    csv_files = [f for f in os.listdir(csv_dir) if f.endswith('.csv')]
    if not csv_files:
        print("❌ 无CSV文件！")
        return

    print("\n===== 收集所有特征列 =====")
    for csv_file in csv_files:
        csv_path = os.path.join(csv_dir, csv_file)
        df = pd.read_csv(csv_path, low_memory=False, usecols=lambda x: x != 'four_tuple')
        feature_cols = [col for col in df.columns if col != 'label']
        useless_cols = detect_useless_cols(df, feature_cols)
        valid_features = [col for col in feature_cols if col not in useless_cols]
        all_feature_cols.extend(valid_features)
    all_feature_cols = list(set(all_feature_cols))  # 去重得到所有文件的特征列
    print(f"📊 所有文件的公共特征列数：{len(all_feature_cols)}")

    # 2. 第二步：初始化全局标签编码器
    label_encoder = LabelEncoder()
    label_encoder.classes_ = np.array([])  # 初始化为空

    # 3. 第三步：逐个预处理文件
    all_dfs = []
    print("\n===== 开始预处理文件 =====")
    for csv_file in csv_files:
        csv_path = os.path.join(csv_dir, csv_file)
        try:
            df = preprocess_single_csv(csv_path, all_feature_cols, label_encoder)
            all_dfs.append(df)
        except Exception as e:
            print(f"❌ 处理{csv_file}失败：{str(e)[:100]}...，跳过")
            continue

    # 4. 合并并保存
    if all_dfs:
        merged_df = pd.concat(all_dfs, ignore_index=True)
        merged_df.to_csv(output_path, index=False, encoding='utf-8')
        print(f"\n📊 合并完成！")
        print(f"   保存路径：{output_path}")
        print(f"   数据形状：{merged_df.shape}")
        print(f"   最终列名：{list(merged_df.columns)}")  # 打印所有列名，验证无新增列

        # 完整打印标签映射（仅基于编码器，无新增列）
        if len(label_encoder.classes_) > 0:
            print("\n🔖 完整标签编码映射（数字编码 → 流量类型）：")
            for idx, cls in enumerate(label_encoder.classes_):
                # 区分良性/恶意，方便查看
                if cls.startswith('Benign_'):
                    print(f"   {idx} → {cls} 【良性流量】")
                elif cls.startswith('Malware_'):
                    print(f"   {idx} → {cls} 【恶意流量】")
                else:
                    print(f"   {idx} → {cls} 【未知类型】")
        print(f"   标签列名：Label")
    else:
        print("❌ 无有效数据！")


if __name__ == '__main__':
    CSV_DIR = '/data/users/trf/datasets/EABWO_FS/processed_USTC-TFC2016_csv'
    OUTPUT_PATH = f'/data/users/trf/datasets/EABWO_FS/preprocessed_all_data_20.csv'
    batch_preprocess_csvs(CSV_DIR, OUTPUT_PATH)