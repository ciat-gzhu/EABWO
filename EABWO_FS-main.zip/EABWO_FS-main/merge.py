import pandas as pd
import os

# 目标文件夹路径（确认这个路径绝对正确）
folder_path = "/data/users/trf/datasets/EABWO_FS/processed_USTC-TFC2016_csv"

# ========== 第一步：调试 - 先检查路径和文件 ==========
# 确认文件夹存在
if not os.path.exists(folder_path):
    print(f"错误：文件夹路径不存在 → {folder_path}")
    exit()

# 列出文件夹下所有文件（方便你核对）
all_files = os.listdir(folder_path)
print(f"文件夹下所有文件（共{len(all_files)}个）：")
for f in all_files:
    print(f"  - {f}")

# ========== 第二步：筛选并读取CSV文件 ==========
# 筛选csv文件（兼容大小写，比如.CSV也能识别）
csv_files = [
    os.path.join(folder_path, filename)
    for filename in all_files
    if filename.lower().endswith(".csv")
]

print(f"\n筛选出的CSV文件（共{len(csv_files)}个）：")
for csv_f in csv_files:
    print(f"  - {csv_f}")

# 读取CSV并加入列表（核心修复：添加append）
dfs = []
for file in csv_files:
    try:
        df = pd.read_csv(file)
        # 关键修复：将读取到的DataFrame添加到列表
        dfs.append(df)
        print(f"✅ 成功读取 {file} → 共{len(df)}行数据")
    except Exception as e:
        print(f"❌ 读取文件 {file} 出错: {e}")

# ========== 第三步：合并并保存 ==========
if not dfs:
    print("\n错误：没有读取到任何有效的CSV数据！")
else:
    # 合并所有DataFrame
    merged_df = pd.concat(dfs, ignore_index=True)
    # 保存合并后的文件
    output_path = os.path.join(folder_path, "merged_all_benign.csv")
    merged_df.to_csv(output_path, index=False)

    # 打印最终结果
    print(f"\n✅ 合并完成！")
    print(f"📁 保存路径：{output_path}")
    print(f"📊 合并统计：共合并{len(csv_files)}个CSV文件 → 总记录数{len(merged_df)}行")